#!/bin/bash

# Nome do executável e diretórios
EXECUTABLE="beholder"
INSTALL_DIR="/opt/agent"
SERVICE_FILE="beholder.service"
SERVICE_PATH="/etc/systemd/system/$SERVICE_FILE"
CONFIG_FILE="env_config.json.enc"
LOG_DIR="/var/log/beholder"

# Criar o diretório de instalação, se não existir
if [ ! -d "$INSTALL_DIR" ]; then
    echo "Creating installation directory $INSTALL_DIR"
    sudo mkdir -p $INSTALL_DIR
fi

# Copiar o executável para o diretório de instalação
echo "Copying $EXECUTABLE to $INSTALL_DIR"
sudo cp $EXECUTABLE $INSTALL_DIR/
sudo chown root:root $INSTALL_DIR/$EXECUTABLE
sudo chmod 755 $INSTALL_DIR/$EXECUTABLE

# Copiar o arquivo de configuração para o diretório de instalação
echo "Copying $CONFIG_FILE to $INSTALL_DIR"
sudo cp $CONFIG_FILE $INSTALL_DIR/

# Criar o diretório de logs, se não existir
if [ ! -d "$LOG_DIR" ]; then
    echo "Creating log directory $LOG_DIR"
    sudo mkdir -p $LOG_DIR
    sudo chown root:root $LOG_DIR
    sudo chmod 755 $LOG_DIR
fi

# Instalar o arquivo de serviço systemd
echo "Installing systemd service file $SERVICE_FILE"
sudo cp $SERVICE_FILE $SERVICE_PATH

# Certificar-se de que as permissões do arquivo de serviço estão corretas
sudo chown root:root $SERVICE_PATH
sudo chmod 644 $SERVICE_PATH

# Recargar os arquivos de unidade do systemd
echo "Reloading systemd daemon"
sudo systemctl daemon-reload

# Habilitar o serviço para iniciar na inicialização do sistema
echo "Enabling $SERVICE_FILE to start at boot"
sudo systemctl enable $SERVICE_FILE

# Iniciar o serviço
echo "Starting $SERVICE_FILE"
sudo systemctl start $SERVICE_FILE

echo "Installation completed successfully."
